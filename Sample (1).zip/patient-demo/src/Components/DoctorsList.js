import React, { useEffect, useState } from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { AppBar, Box, Toolbar, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DoctorsForm from '../Ui/Doctors_Form';
import { Delete, Edit } from '@mui/icons-material';
import { useDispatch, useSelector } from "react-redux";
import { deleteDoctor, findDoctorByFirstName, retriveDoctors } from '../Actions/Doctors';
import SearchBar from '../Ui/SearchBar';

export default function DoctorsList() {
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState(false);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [doctor, setDoctor]=useState({});

  const doctors = useSelector(state => state.doctors);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(retriveDoctors())
  }, [dispatch]);


const removeDoctor=(id)=>{
  dispatch(deleteDoctor(id)) 
}

const editDoctor=(doctor)=>{
  setDoctor(doctor);
  setOpen(true);
}
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleDoctorsForm=(isopen)=>{
        setDoctor({});
        setOpen(isopen);
      
  }
  const searchHandler=e=>{
    const { value } = e.target;
    dispatch(findDoctorByFirstName(value))
  }
  const FormClose=()=>{
        setOpen(false);
  }

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <>
    <Paper sx={{ width: '100%', overflow: 'hidden' }} style={{marginTop:"50px"}}>
        <AppBar position="static">
        <Toolbar variant="dense">
          <Typography variant="h6" color="inherit" component="div">
            Doctors List 
          </Typography>
          <Box style={{position:'absolute',right:'10px'}}> 
          <SearchBar placeholder="Search"  onChange={searchHandler}/>
          <AddIcon onClick={()=>handleDoctorsForm(true)} />
          </Box>
        </Toolbar>
      </AppBar>
      <TableContainer style={{ maxHeight: 440 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              {doctors[0]&&Object.keys(doctors[0]).map((column) => {
               
                return(
                <TableCell
                  key={column}
                  style={{fontWeight:"bold",fontSize:'15px',textTransform:"capitalize" ,display:column.toLowerCase() ==="id"?"none":"table-cell"}}
                >
                  {column}
                </TableCell>
              )}
              )}
              { doctors[0]&&<TableCell
                  key="actions"
                  style={{fontWeight:"bold",fontSize:'15px',textTransform:"capitalize" }}
                >
                  Actions
                </TableCell>}
            </TableRow>
          </TableHead>
          <TableBody>
            {doctors&&doctors
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row,index) => {
                return (
                  <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                    {Object.keys(doctors[0]).map((column) => {
                      
                      const value = row[column];
                      return (
                        <TableCell style={{display:column.toLowerCase() ==="id"?"none":"table-cell"}} key={column} >
                          {value}
                        </TableCell>
                      );
                    })}
                      <TableCell key="actions">
                         <Edit  onClick={()=>editDoctor(row)}/>
                          <Delete onClick={()=>removeDoctor(row["id"])}/>
                        </TableCell>
              
                  </TableRow>
                );
              })
           
              }
               { doctors.length===0?
               
              <TableRow>
                <h5 style={{textAlign:"center"}}>No Records Found..</h5>
              </TableRow>
              :null
              }
            
          </TableBody>
        </Table>
      </TableContainer>
      {doctors.length!==0?<TablePagination
        rowsPerPageOptions={[5,10, 25, 100]}
        component="div"
        count={doctors.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />:""}
    </Paper>
    {doctor && <DoctorsForm doctor={doctor}  FormClose={FormClose} open={open}/>}
    </>
  );
}

import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';


const Header = () => {
  return (
    <AppBar  position="fixed"
    sx={{ width: `calc(100% - 200px)`, ml: `200px` }}>
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <h3>Ascension</h3>
          <Box sx={{ flexGrow: 1, display: { md: 'flex' } }} className="header-menu">
             <Link to="/doctors">
              <Button
                key="Doctors"
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Doctors
              </Button>
              </Link>
              <Link to="/patients">
              <Button
                key="Patients"
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Patients
              </Button>
              </Link>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};
export default Header;

import API from "../Utils/API";
const getAllPatients = () => {
  return API.get("/patients");
};
const getPatient = id => {
  return API.get(`/patients/${id}`);
};
const createPatient = data => {
  return API.post("/patients", data);
};
const updatePatient = (id, data) => {
  return API.put(`/patients/${id}`, data);
};
const removePatient = id => {
  return API.delete(`/patients/${id}`);
};
const removeAllPatients = () => {
  return API.delete(`/patients`);
};
const findByName = title => {
  return API.get(`/patients?q=${title}`);
};
const PatientsService = {
    getAllPatients,
    getPatient,
    createPatient,
    updatePatient,
    removePatient,
    removeAllPatients,
    findByName
};
export default PatientsService;
import API from "../Utils/API";
const getAllDoctors = () => {
  return API.get("/doctors");
};
const getDoctor = id => {
  return API.get(`/doctors/${id}`);
};
const createDoctor = data => {
  return API.post("/doctors", data);
};
const updateDoctor = (id, data) => {
  return API.put(`/doctors/${id}`, data);
};
const removeDoctor = id => {
  return API.delete(`/doctors/${id}`);
};
const removeAllDoctors = () => {
  return API.delete(`/doctors`);
};
const findByName = title => {
  return API.get(`/doctors?q=${title}`);
};
const DoctorsService = {
    getAllDoctors,
    getDoctor,
    createDoctor,
    updateDoctor,
    removeDoctor,
    removeAllDoctors,
    findByName
};
export default DoctorsService;
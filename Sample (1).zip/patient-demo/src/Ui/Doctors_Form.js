import * as React from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import {
  Box,
  Container,
  CssBaseline,
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  Grid,
  Radio,
  RadioGroup,
} from "@mui/material";
import { Close } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { createDoctor, updateDoctor } from "../Actions/Doctors";

export default function Doctors_Form(props) {

  const dispatch = useDispatch();

  const [open, setOpen] = React.useState(props.open);
  const [doctor, setDoctor] = React.useState({
    id: "",
    firstname: "",
    lastname: "",
    location: "",
    specialization: "",
    sex: "",
    contact: ""
  });
  const [error, setError] = React.useState({
    firstname: false,
    f_helpertext:"",
    lastname: false,
    l_helpertext:"",
    location: false,
    lo_helpertext:"",
    specialization: false,
    sp_helpertext:"",
    sex:false,
    se_helpertext:"",
    contact:false ,
    co_helpertext:""

  });

  const handleChange = e => {
    const { name, value } = e.target;
    setDoctor(prevState => ({
      ...prevState,
      [name]: value
    }));
  };
  React.useEffect(() => {
    setDoctor({
      id: props.doctor.id,
      firstname: props.doctor.firstname,
      lastname: props.doctor.lastname,
      location: props.doctor.location,
      specialization: props.doctor.specialization,
      sex: props.doctor.sex,
      contact: props.doctor.contact
    })
    setError({})
  }, [props.doctor])

const validateForm=(doctorVal)=>{
  if(doctorVal.firstname.trim()===""){
    return setError({
       firstname: true,
       f_helpertext:"First Name is required"
     });
   }else if(doctorVal.lastname.trim()===""){
     return setError({
        lastname: true,
        l_helpertext:"Last Name is required"
      });
    }
    else if(doctorVal.specialization.trim()===""){
     return setError({
        specialization: true,
        sp_helpertext:"Specialization is required"
      });
    }
    else if(doctorVal.location.trim()===""){
     return setError({
        location:true,
        lo_helpertext:"Location is required"
      });
    }
    else if(doctorVal.sex===null ){
     return setError({
        sex: true,
        se_helpertext:"Gender is required"
      });
    }
    else if(doctorVal.contact.trim()===""){
     return setError({
        contact: true,
        co_helpertext:"Contact is required"
      });
    }
    else{
      return true;
    }
}

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const doctor = {
      firstname: data.get("firstname"),
      lastname: data.get("lastname"),
      specialization: data.get("specialization"),
      location: data.get("location"),
      sex: data.get("sex"),
      contact: data.get("contact"),
    }

     if(validateForm(doctor)){

    if (Object.keys(props.doctor).length === 0) {
      dispatch(createDoctor(doctor))
        .then(res => {
          console.log(res);
        })
        .catch(e => {
          console.log(e);
        });
    } else {

      dispatch(updateDoctor(props.doctor.id, doctor))
        .then(response => {
          console.log(response);
        })
        .catch(e => {
          console.log(e);
        });

    }
    handleClose();
  }
  };

  React.useEffect(() => {
    setOpen(props.open);
  }, [props.open]);

  const handleClose = () => {
    setOpen(false);
    props.FormClose(false);
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Doctors Registration   <Close onClick={handleClose} style={{ float: "right" }} /></DialogTitle>
      <DialogContent>
        <Container component="main" maxWidth="xs">
          <CssBaseline />
          <Box
            component="form"
            noValidate
            onSubmit={handleSubmit}
            sx={{ mt: 3 }}
          >
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="firstname"
                  required
                  helperText={error.firstname&&error.f_helpertext}
                  fullWidth
                  id="firstName"
                  label="First Name"
                  error={error.firstname}
                  autoFocus
                  value={doctor.firstname}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="lastName"
                  label="Last Name"
                  helperText={error.lastname&&error.l_helpertext}
                  error={error.lastname}
                  name="lastname"
                  value={doctor.lastname}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="specialization"
                  label="Specialization"
                  helperText={error.specialization&&error.sp_helpertext}
                  error={error.specialization}
                  name="specialization"
                  value={doctor.specialization}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="location"
                  label="Location"
                  helperText={error.location&&error.lo_helpertext}
                  error={error.location}
                  name="location"
                  value={doctor.location}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl error={error.sex}>
                  <FormLabel id="radio-buttons">
                    Gender
                  </FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="radio-buttons"
                    name="sex"
                    value={doctor.sex}
                    onChange={handleChange}
                  >
                    <FormControlLabel
                      value="Female"
                      control={<Radio />}
                      label="Female"
                      
                    />
                    <FormControlLabel
                      value="Male"
                      control={<Radio />}
                      label="Male"
                    />
                    <FormControlLabel
                      value="other"
                      control={<Radio />}
                      label="Other"
                    />
                  </RadioGroup>
                  <FormHelperText>{error.sex&&error.se_helpertext}</FormHelperText>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="contact"
                  label="Contact"
                  type="number"
                  helperText={error.contact&&error.co_helpertext}
                  error={error.contact}
                  name="contact"
                  value={doctor.contact}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Save
            </Button>
          </Box>
        </Container>
      </DialogContent>
    </Dialog>
  );
}

import * as React from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import {
  Box,
  Container,
  CssBaseline,
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  Grid,
  InputLabel,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
} from "@mui/material";
import CustomDateTimePicker from "./CustomDateTimePickers";
import { Close } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { createPatient, updatePatient } from "../Actions/Patients";

export default function Patient_Form(props) {
  const dispatch = useDispatch();
  const [open, setOpen] = React.useState(props.open);
  //const [assignedDotcor, setAssignedDotcor] = React.useState('');
  const doctors = useSelector(state => state.doctors);
  const [patient, setPatient] = React.useState({
                                                id:"", firstname:"",lastname:"", email:"", problem:"",
                                                address:"",  age:"", sex:"", contact:"",emergency_contact:"",
                                                doctor_name:"",timeslot:""
                                              });
  const [error, setError] = React.useState({
    firstname: false,
    f_helpertext:"",
    lastname: false,
    l_helpertext:"",
    email:false,
    em_helpertext:"",
    problem:false,
    pr_helpertext:"",
    address: false,
    ad_helpertext:"",
    age:false,
    age_helpertext:"",
    emergency_contact: false,
    emc_helpertext:"",
    sex:false,
    se_helpertext:"",
    contact:false ,
    co_helpertext:"",
    doctor_name:false,
    do_helpertext:"",
    timeslot:false ,
    time_helpertext:""

  });
  //const {id,firstname,lastname,email,problem,address,age,sex,contact,emergency_contact,doctor_name,timeslot} = props.patient;
 
  React.useEffect(() => {
    setPatient({
      id:props.patient.id,
      firstname:props.patient.firstname,
      lastname:props.patient.lastname,
      email:props.patient.email,
      problem:props.patient.problem,
      address:props.patient.address,
      age:props.patient.age,
      sex:props.patient.sex,
      contact:props.patient.contact,
      emergency_contact:props.patient.emergency_contact,
      doctor_name:props.patient.doctor_name,
      timeslot:props.patient.timeslot
    })
  }, [props.patient]);

  React.useEffect(() => {
    setOpen(props.open);
  }, [props.open]);

  const handleChange = e => {
    const { name, value } = e.target;
    setPatient(prevState => ({
      ...prevState,
      [name]: value
    }));
  };
  const handleDateChange = (Time) => {
    setPatient(prevState => ({
      ...prevState,
      timeslot:Time
    }));
  };
  const validateForm=(patientVal)=>{
    if(patientVal.firstname.trim()===""){
      return setError({
         firstname: true,
         f_helpertext:"First Name is required"
       });
     }else if(patientVal.lastname.trim()===""){
       return setError({
          lastname: true,
          l_helpertext:"Last Name is required"
        });
      }
      else if(patientVal.email.trim()===""){
       return setError({
          email: true,
          em_helpertext:"Email is required"
        });
      }
      else if(patientVal.problem.trim()===""){
       return setError({
          problem:true,
          pr_helpertext:"Please Specify the Problem "
        });
      }
      else if(patientVal.address==="" ){
       return setError({
          address: true,
          ad_helpertext:"Address is required"
        });
      }
      else if(patientVal.sex===null){
        return setError({
           sex: true,
           se_helpertext:"Gender is required"
         });
       }
      else if(patientVal.age.trim()===""){
       return setError({
          age: true,
          age_helpertext:"Age is required"
        });
      }
   
       else if(patientVal.contact.trim()===""){
        return setError({
           contact:true,
           co_helpertext:"Contact is required"
         });
       }
       else if(patientVal.emergency_contact==="" ){
        return setError({
           emergency_contact: true,
           emc_helpertext:"Emergency Contact is required"
         });
       }
       else if(patientVal.doctor_name.trim()===""){
        return setError({
           doctor_name: true,
           do_helpertext:"Please Assign a Doctor"
         });
       }
      
      else{
        return true;
      }

  }

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const patientData = {
      firstname:data.get("firstname"),
      lastname:data.get("lastname"),
      email:data.get("email"),
      problem:data.get("problem"),
      address:data.get("location"),
      age:data.get("age"),
      sex:data.get("gender"),
      contact:data.get("contact"),
      emergency_contact:data.get("emergency_contact"),
      doctor_name:data.get("assigneddoctor"),
      timeslot:patient.timeslot
    }


    if(validateForm(patientData)){
    if (Object.keys(props.patient).length === 0) {
      dispatch(createPatient(patientData))
    } else {
      dispatch(updatePatient(props.patient.id, patientData))
    }
    handleClose();
  }
  };


  const handleClose = () => {
    setOpen(false);
    props.FormClose(false);
  };

  return (
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Patient Registration  <Close onClick={handleClose} style={{float:"right"}}/></DialogTitle>
        <DialogContent>
          <Container component="main" maxWidth="xs">
            <CssBaseline />
            <Box
              component="form"
              onSubmit={handleSubmit}
              noValidate
              sx={{ mt: 3 }}
            >
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    name="firstname"
                    required
                    fullWidth
                    helperText={error.firstname&&error.f_helpertext}
                    error={error.firstname}
                    id="firstName"
                    label="First Name"
                    size="small"
                    value={patient.firstname}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    helperText={error.lastname&&error.l_helpertext}
                    error={error.lastname}
                    id="lastName"
                    label="Last Name"
                    name="lastname"
                    size="small"
                    value={patient.lastname}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={12}>
                  <TextField
                    required
                    fullWidth
                    id="email"
                    helperText={error.email&&error.em_helpertext}
                    error={error.email}
                    label="Email"
                    size="small"
                    name="email"
                    value={patient.email}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="problem"
                    helperText={error.problem&&error.pr_helpertext}
                    error={error.problem}
                    label="Problem"
                    size="small"
                    name="problem"
                    value={patient.problem}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    helperText={error.address&&error.ad_helpertext}
                    error={error.address}
                    id="location"
                    label="Location"
                    size="small"
                    name="location"
                    value={patient.address}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12}>
                  <FormControl error={error.sex}>
                    <FormLabel id="demo-row-radio-buttons-group-label">
                      Gender
                    </FormLabel>
                    <RadioGroup
                      row
                      aria-labelledby="demo-row-radio-buttons-group-label"
                      name="gender"
                      size="small"
                      defaultValue={patient.sex}
                      onChange={handleChange}
                    >
                      <FormControlLabel
                        value="Female"
                        control={<Radio />}
                        label="Female"
                      />
                      <FormControlLabel
                        value="Male"
                        control={<Radio />}
                        label="Male"
                      />
                      <FormControlLabel
                        value="other"
                        control={<Radio />}
                        label="Other"
                      />
                    </RadioGroup>
                    <FormHelperText>{error.sex&&error.se_helpertext}</FormHelperText>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    helperText={error.age&&error.age_helpertext}
                    error={error.age}
                    id="age"
                    type="number"
                    size="small"
                    label="Age"
                    name="age"
                    value={patient.age}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    helperText={error.contact&&error.co_helpertext}
                    error={error.contact}
                    type="number"
                    id="contact"
                    label="Contact"
                    size="small"
                    name="contact"
                    value={patient.contact}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={6} sm={6}>
                  <TextField
                    required
                    fullWidth
                    helperText={error.emergency_contact&&error.emc_helpertext}
                    error={error.emergency_contact}
                    type="number"
                    id="emergencycontact"
                    label="Emer Contact"
                    size="small"
                    name="emergency_contact"
                    value={patient.emergency_contact}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={6} sm={6} >
                <FormControl sx={{ minWidth: '100%' }} size="small" error={error.doctor_name}>
                  <InputLabel id="demo-select-small">Assigned Doctor</InputLabel>
                  <Select
                    labelId="demo-select-small"
                    id="demo-select-small"
                    label="Assigned Doctor"
                    name="assigneddoctor"
                    onChange={handleChange}
                    defaultValue={patient.doctor_name}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    {doctors.map((doctor)=>{
                      return(
                      <MenuItem key={doctor.id} value={doctor.firstname}>{doctor.firstname +"  ,     "+doctor.specialization}</MenuItem>
                      )
                    })
                    }
                  </Select>
                  <FormHelperText>{error.doctor_name&&error.do_helpertext}</FormHelperText>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={12}>
                <CustomDateTimePicker defaultValue={patient.timeslot} onChange={handleDateChange}/>
                </Grid>
              </Grid>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                sx={{ mt: 3, mb: 2 }}
              >
                Save
              </Button>
            </Box>
          </Container>
        </DialogContent>
      </Dialog>
  );
}

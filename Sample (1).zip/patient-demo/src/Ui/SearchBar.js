import { TextField } from '@mui/material'
import React, { useState } from 'react'


function SearchBar(props) {
const [title,setTitle]=useState("");

const handleChange=e=>{
    const {value}=e.target;
    setTitle(value)
    props.onChange(e)
}

  return (
    <TextField
    type="search"
    size="small"
    name='search'
    value={title}
    onChange={handleChange}
    style={{marginLeft:'20px',marginRight:'40px'}}
    className="searchbar"
    placeholder={props.placeholder}
    />
  )
}

export default SearchBar
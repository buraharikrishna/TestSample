import './App.css';
import AdminDrawer from './Ui/AdminDrawer';

function App() {
  return (
    <AdminDrawer/>
  );
}

export default App;

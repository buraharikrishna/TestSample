import DoctorsService from "../Services/DoctorsService"
import { CREATE_DOCTOR, DELETE_ALL_DOCTORS, DELETE_DOCTOR, RETRIEVE_DOCTORS, UPDATE_DOCTOR } from "./type";



export const createDoctor = (data) => async (dispatch) => {
    try {
        const res = await DoctorsService.createDoctor(data);
        dispatch({
            type: CREATE_DOCTOR,
            payload: res.data,
        });
        return Promise.resolve(res.data);
    }
    catch (error) {
        return Promise.reject(error);
    }

}
export const retriveDoctors=()=> async (dispatch)=>{
    try {
        const res= await DoctorsService.getAllDoctors();
            dispatch({
                type:RETRIEVE_DOCTORS,
                payload:res.data,
            });
    } catch (error) {
        console.log(error);
    }
}
  export const updateDoctor = (id, data) => async (dispatch) => {
    try {
      const res = await DoctorsService.updateDoctor(id, data);
      dispatch({
        type: UPDATE_DOCTOR,
        payload: res.data,
      });
      return Promise.resolve(res.data);
    } catch (err) {
      return Promise.reject(err);
    }
  };
  export const deleteDoctor = (id) => async (dispatch) => {
    try {
      await DoctorsService.removeDoctor(id);
      dispatch({
        type: DELETE_DOCTOR,
        payload: { id },
      });
    } catch (err) {
      console.log(err);
    }
  };
  export const deleteAllDoctors = () => async (dispatch) => {
    try {
      const res = await DoctorsService.removeAllDoctors();
      dispatch({
        type: DELETE_ALL_DOCTORS,
        payload: res.data,
      });
      return Promise.resolve(res.data);
    } catch (err) {
      return Promise.reject(err);
    }
  };
  export const findDoctorByFirstName = (title) => async (dispatch) => {
    try {
      const res = await DoctorsService.findByName(title);
      dispatch({
        type: RETRIEVE_DOCTORS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
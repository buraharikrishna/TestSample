import PatientsService from "../Services/PatientService";
import { CREATE_PATIENT, DELETE_ALL_PATIENTS, DELETE_PATIENT, RETRIEVE_PATIENTS, UPDATE_PATIENT } from "./type";


export const createPatient = (data) => async (dispatch) => {
    try {
        const res = await PatientsService.createPatient(data);
        dispatch({
            type: CREATE_PATIENT,
            payload: res.data,
        });
        return Promise.resolve(res.data);
    }
    catch (error) {
        return Promise.reject(error);
    }

}
export const retrivePatients=()=> async (dispatch)=>{
    try {
        const res= await PatientsService.getAllPatients();
            dispatch({
                type:RETRIEVE_PATIENTS,
                payload:res.data,
            });
    } catch (error) {
        console.log(error);
    }
}
  export const updatePatient = (id, data) => async (dispatch) => {
    try {
      const res = await PatientsService.updatePatient(id, data);
      dispatch({
        type: UPDATE_PATIENT,
        payload: res.data,
      });
      return Promise.resolve(res.data);
    } catch (err) {
      return Promise.reject(err);
    }
  };
  export const deletePatient = (id) => async (dispatch) => {
    try {
      await PatientsService.removePatient(id);
      dispatch({
        type: DELETE_PATIENT,
        payload: { id },
      });
    } catch (err) {
      console.log(err);
    }
  };
  export const deleteAllPatients = () => async (dispatch) => {
    try {
      const res = await PatientsService.removeAllPatients();
      dispatch({
        type: DELETE_ALL_PATIENTS,
        payload: res.data,
      });
      return Promise.resolve(res.data);
    } catch (err) {
      return Promise.reject(err);
    }
  };
  export const findPatientByFirstName = (title) => async (dispatch) => {
    try {
      const res = await PatientsService.findByName(title);
      dispatch({
        type: RETRIEVE_PATIENTS,
        payload: res.data,
      });
    } catch (err) {
      console.log(err);
    }
  };
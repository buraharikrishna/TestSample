import { combineReducers } from "redux";
import doctors from "./Doctors"
import patients from "./Patients"
export default combineReducers({
    doctors,
    patients
});
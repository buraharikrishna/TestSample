import { CREATE_PATIENT, DELETE_ALL_PATIENTS, DELETE_PATIENT, RETRIEVE_PATIENTS, UPDATE_PATIENT } from "../Actions/type";

const initialState = [];
function PatientReducer(patients = initialState, action) {
  const { type, payload } = action;
  switch (type) {
    case CREATE_PATIENT:
      return [...patients, payload];
    case RETRIEVE_PATIENTS:
      return payload;
    case UPDATE_PATIENT:
      return patients.map((patient) => {
        if (patient.id === payload.id) {
          return {
            ...patient,
            ...payload,
          };
        } else {
          return patient;
        }
      });
    case DELETE_PATIENT:
      return patients.filter(({ id }) => id !== payload.id);
    case DELETE_ALL_PATIENTS:
      return [];
    default:
      return patients;
  }
};
export default PatientReducer;
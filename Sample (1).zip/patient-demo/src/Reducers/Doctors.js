import { CREATE_DOCTOR, DELETE_ALL_DOCTORS, DELETE_DOCTOR, RETRIEVE_DOCTORS, UPDATE_DOCTOR } from "../Actions/type";

const initialState = [];
function DoctorReducer(doctors = initialState, action) {
  const { type, payload } = action;
  switch (type) {
    case CREATE_DOCTOR:
      return [...doctors, payload];
    case RETRIEVE_DOCTORS:
      return payload;
    case UPDATE_DOCTOR:
      return doctors.map((doctor) => {
        if (doctor.id === payload.id) {
          return {
            ...doctor,
            ...payload,
          };
        } else {
          return doctor;
        }
      });
    case DELETE_DOCTOR:
      return doctors.filter(({ id }) => id !== payload.id);
    case DELETE_ALL_DOCTORS:
      return [];
    default:
      return doctors;
  }
};
export default DoctorReducer;
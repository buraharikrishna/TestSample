import axios from "axios";

const BASE_URL="http://localhost:4000"
const API=axios.create();
API.defaults.baseURL=BASE_URL;

export default API;
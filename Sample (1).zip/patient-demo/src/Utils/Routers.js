import React from 'react'
import { Container } from '@mui/material'
import { Route, Routes } from 'react-router-dom'
import DoctorsList from '../Components/DoctorsList'
import PatientsList from '../Components/PatientsList'

function Routers() {
  return (
      <Container maxWidth="lg">
    <Routes>
        <Route path="/"  element={<DoctorsList />} />
        <Route path="/doctors" element={<DoctorsList />} />
        <Route path="/patients" element={<PatientsList />} />
    </Routes>
    </Container>
  )
}

export default Routers